package courriers.content;

public interface Content {
	/**
	 * Returns the description of the letter. 
	 * @return
	 */
	public String description();
}
