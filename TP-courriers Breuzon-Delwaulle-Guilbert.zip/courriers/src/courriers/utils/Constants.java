package courriers.utils;

/**
 * @author Loic
 * A sample class which contains all important constants of the project
 */
public class Constants {
	
	public static final int MAX_PROMISSORY_NOTE_AMOUNT=1000;
	public static final int INITIAL_BANK_AMOUNT=5000;
	public static final int COST_OF_SIMPLE_LETTER=1;

}
